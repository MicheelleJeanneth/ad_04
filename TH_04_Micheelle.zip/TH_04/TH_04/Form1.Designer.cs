﻿namespace TH_04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbl_SoccerTL = new System.Windows.Forms.Label();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.cobox_Country = new System.Windows.Forms.ComboBox();
            this.listbox_Player = new System.Windows.Forms.ListBox();
            this.lbl_ChooseCountry = new System.Windows.Forms.Label();
            this.lbl_ChooseTeam = new System.Windows.Forms.Label();
            this.cobox_Team = new System.Windows.Forms.ComboBox();
            this.lbl_TeamCountry = new System.Windows.Forms.Label();
            this.lbl_TeamName = new System.Windows.Forms.Label();
            this.lbl_AddingTeam = new System.Windows.Forms.Label();
            this.lbl_TeamCity = new System.Windows.Forms.Label();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.btn_AddPlayer = new System.Windows.Forms.Button();
            this.lbl_PlayerPosition = new System.Windows.Forms.Label();
            this.lbl_AddingPlayers = new System.Windows.Forms.Label();
            this.lbl_PlayerNumber = new System.Windows.Forms.Label();
            this.lbl_PlayerName = new System.Windows.Forms.Label();
            this.txbx_teamcountry = new System.Windows.Forms.TextBox();
            this.txbx_teamcity = new System.Windows.Forms.TextBox();
            this.txbx_teamname = new System.Windows.Forms.TextBox();
            this.txbx_playername = new System.Windows.Forms.TextBox();
            this.txbx_playernumber = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.cobox_playerposition = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_SoccerTL
            // 
            this.lbl_SoccerTL.AutoSize = true;
            this.lbl_SoccerTL.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SoccerTL.Location = new System.Drawing.Point(14, 12);
            this.lbl_SoccerTL.Name = "lbl_SoccerTL";
            this.lbl_SoccerTL.Size = new System.Drawing.Size(161, 23);
            this.lbl_SoccerTL.TabIndex = 0;
            this.lbl_SoccerTL.Text = "Soccer Team List";
            // 
            // btn_Remove
            // 
            this.btn_Remove.Font = new System.Drawing.Font("Cambria", 9F);
            this.btn_Remove.Location = new System.Drawing.Point(18, 400);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(99, 33);
            this.btn_Remove.TabIndex = 3;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // cobox_Country
            // 
            this.cobox_Country.FormattingEnabled = true;
            this.cobox_Country.Items.AddRange(new object[] {
            "England",
            "Italy"});
            this.cobox_Country.Location = new System.Drawing.Point(162, 53);
            this.cobox_Country.Name = "cobox_Country";
            this.cobox_Country.Size = new System.Drawing.Size(204, 28);
            this.cobox_Country.TabIndex = 1;
            this.cobox_Country.SelectedIndexChanged += new System.EventHandler(this.cobox_Country_SelectedIndexChanged);
            this.cobox_Country.Click += new System.EventHandler(this.cobox_Country_Click);
            this.cobox_Country.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cobox_Country_KeyDown);
            // 
            // listbox_Player
            // 
            this.listbox_Player.FormattingEnabled = true;
            this.listbox_Player.ItemHeight = 20;
            this.listbox_Player.Location = new System.Drawing.Point(18, 161);
            this.listbox_Player.Name = "listbox_Player";
            this.listbox_Player.Size = new System.Drawing.Size(348, 224);
            this.listbox_Player.TabIndex = 3;
            // 
            // lbl_ChooseCountry
            // 
            this.lbl_ChooseCountry.AutoSize = true;
            this.lbl_ChooseCountry.Font = new System.Drawing.Font("Cambria", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChooseCountry.Location = new System.Drawing.Point(14, 58);
            this.lbl_ChooseCountry.Name = "lbl_ChooseCountry";
            this.lbl_ChooseCountry.Size = new System.Drawing.Size(142, 21);
            this.lbl_ChooseCountry.TabIndex = 4;
            this.lbl_ChooseCountry.Text = "Choose Country :";
            // 
            // lbl_ChooseTeam
            // 
            this.lbl_ChooseTeam.AutoSize = true;
            this.lbl_ChooseTeam.Font = new System.Drawing.Font("Cambria", 9F);
            this.lbl_ChooseTeam.Location = new System.Drawing.Point(14, 113);
            this.lbl_ChooseTeam.Name = "lbl_ChooseTeam";
            this.lbl_ChooseTeam.Size = new System.Drawing.Size(123, 21);
            this.lbl_ChooseTeam.TabIndex = 5;
            this.lbl_ChooseTeam.Text = "Choose Team :";
            // 
            // cobox_Team
            // 
            this.cobox_Team.FormattingEnabled = true;
            this.cobox_Team.Location = new System.Drawing.Point(162, 108);
            this.cobox_Team.Name = "cobox_Team";
            this.cobox_Team.Size = new System.Drawing.Size(204, 28);
            this.cobox_Team.TabIndex = 2;
            this.cobox_Team.SelectedIndexChanged += new System.EventHandler(this.cobox_Team_SelectedIndexChanged);
            this.cobox_Team.Click += new System.EventHandler(this.cobox_Team_Click);
            // 
            // lbl_TeamCountry
            // 
            this.lbl_TeamCountry.AutoSize = true;
            this.lbl_TeamCountry.Font = new System.Drawing.Font("Cambria", 9F);
            this.lbl_TeamCountry.Location = new System.Drawing.Point(399, 108);
            this.lbl_TeamCountry.Name = "lbl_TeamCountry";
            this.lbl_TeamCountry.Size = new System.Drawing.Size(128, 21);
            this.lbl_TeamCountry.TabIndex = 9;
            this.lbl_TeamCountry.Text = "Team Country :";
            // 
            // lbl_TeamName
            // 
            this.lbl_TeamName.AutoSize = true;
            this.lbl_TeamName.Font = new System.Drawing.Font("Cambria", 9F);
            this.lbl_TeamName.Location = new System.Drawing.Point(399, 53);
            this.lbl_TeamName.Name = "lbl_TeamName";
            this.lbl_TeamName.Size = new System.Drawing.Size(111, 21);
            this.lbl_TeamName.TabIndex = 8;
            this.lbl_TeamName.Text = "Team Name :";
            // 
            // lbl_AddingTeam
            // 
            this.lbl_AddingTeam.AutoSize = true;
            this.lbl_AddingTeam.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lbl_AddingTeam.Location = new System.Drawing.Point(399, 7);
            this.lbl_AddingTeam.Name = "lbl_AddingTeam";
            this.lbl_AddingTeam.Size = new System.Drawing.Size(130, 23);
            this.lbl_AddingTeam.TabIndex = 11;
            this.lbl_AddingTeam.Text = "Adding Team";
            // 
            // lbl_TeamCity
            // 
            this.lbl_TeamCity.AutoSize = true;
            this.lbl_TeamCity.Font = new System.Drawing.Font("Cambria", 9F);
            this.lbl_TeamCity.Location = new System.Drawing.Point(399, 161);
            this.lbl_TeamCity.Name = "lbl_TeamCity";
            this.lbl_TeamCity.Size = new System.Drawing.Size(96, 21);
            this.lbl_TeamCity.TabIndex = 12;
            this.lbl_TeamCity.Text = "Team City :";
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.Font = new System.Drawing.Font("Cambria", 9F);
            this.btn_AddTeam.Location = new System.Drawing.Point(573, 203);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(111, 46);
            this.btn_AddTeam.TabIndex = 7;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = true;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // btn_AddPlayer
            // 
            this.btn_AddPlayer.Font = new System.Drawing.Font("Cambria", 9F);
            this.btn_AddPlayer.Location = new System.Drawing.Point(940, 205);
            this.btn_AddPlayer.Name = "btn_AddPlayer";
            this.btn_AddPlayer.Size = new System.Drawing.Size(111, 46);
            this.btn_AddPlayer.TabIndex = 11;
            this.btn_AddPlayer.Text = "Add";
            this.btn_AddPlayer.UseVisualStyleBackColor = true;
            this.btn_AddPlayer.Click += new System.EventHandler(this.btn_AddPlayer_Click);
            // 
            // lbl_PlayerPosition
            // 
            this.lbl_PlayerPosition.AutoSize = true;
            this.lbl_PlayerPosition.Font = new System.Drawing.Font("Cambria", 9F);
            this.lbl_PlayerPosition.Location = new System.Drawing.Point(749, 161);
            this.lbl_PlayerPosition.Name = "lbl_PlayerPosition";
            this.lbl_PlayerPosition.Size = new System.Drawing.Size(136, 21);
            this.lbl_PlayerPosition.TabIndex = 20;
            this.lbl_PlayerPosition.Text = "Player Position :";
            // 
            // lbl_AddingPlayers
            // 
            this.lbl_AddingPlayers.AutoSize = true;
            this.lbl_AddingPlayers.Font = new System.Drawing.Font("Cambria", 10F, System.Drawing.FontStyle.Bold);
            this.lbl_AddingPlayers.Location = new System.Drawing.Point(749, 7);
            this.lbl_AddingPlayers.Name = "lbl_AddingPlayers";
            this.lbl_AddingPlayers.Size = new System.Drawing.Size(146, 23);
            this.lbl_AddingPlayers.TabIndex = 19;
            this.lbl_AddingPlayers.Text = "Adding Players";
            // 
            // lbl_PlayerNumber
            // 
            this.lbl_PlayerNumber.AutoSize = true;
            this.lbl_PlayerNumber.Font = new System.Drawing.Font("Cambria", 9F);
            this.lbl_PlayerNumber.Location = new System.Drawing.Point(749, 108);
            this.lbl_PlayerNumber.Name = "lbl_PlayerNumber";
            this.lbl_PlayerNumber.Size = new System.Drawing.Size(135, 21);
            this.lbl_PlayerNumber.TabIndex = 17;
            this.lbl_PlayerNumber.Text = "Player Number :";
            // 
            // lbl_PlayerName
            // 
            this.lbl_PlayerName.AutoSize = true;
            this.lbl_PlayerName.Font = new System.Drawing.Font("Cambria", 9F);
            this.lbl_PlayerName.Location = new System.Drawing.Point(749, 53);
            this.lbl_PlayerName.Name = "lbl_PlayerName";
            this.lbl_PlayerName.Size = new System.Drawing.Size(117, 21);
            this.lbl_PlayerName.TabIndex = 16;
            this.lbl_PlayerName.Text = "Player Name :";
            // 
            // txbx_teamcountry
            // 
            this.txbx_teamcountry.Location = new System.Drawing.Point(533, 108);
            this.txbx_teamcountry.Name = "txbx_teamcountry";
            this.txbx_teamcountry.Size = new System.Drawing.Size(207, 26);
            this.txbx_teamcountry.TabIndex = 5;
            // 
            // txbx_teamcity
            // 
            this.txbx_teamcity.Location = new System.Drawing.Point(533, 161);
            this.txbx_teamcity.Name = "txbx_teamcity";
            this.txbx_teamcity.Size = new System.Drawing.Size(207, 26);
            this.txbx_teamcity.TabIndex = 6;
            // 
            // txbx_teamname
            // 
            this.txbx_teamname.Location = new System.Drawing.Point(533, 53);
            this.txbx_teamname.Name = "txbx_teamname";
            this.txbx_teamname.Size = new System.Drawing.Size(207, 26);
            this.txbx_teamname.TabIndex = 4;
            // 
            // txbx_playername
            // 
            this.txbx_playername.Location = new System.Drawing.Point(885, 50);
            this.txbx_playername.Name = "txbx_playername";
            this.txbx_playername.Size = new System.Drawing.Size(207, 26);
            this.txbx_playername.TabIndex = 8;
            // 
            // txbx_playernumber
            // 
            this.txbx_playernumber.Location = new System.Drawing.Point(885, 105);
            this.txbx_playernumber.Name = "txbx_playernumber";
            this.txbx_playernumber.Size = new System.Drawing.Size(207, 26);
            this.txbx_playernumber.TabIndex = 9;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(418, 205);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(42, 38);
            this.dataGridView1.TabIndex = 29;
            this.dataGridView1.Visible = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(785, 205);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(42, 38);
            this.dataGridView2.TabIndex = 30;
            this.dataGridView2.Visible = false;
            // 
            // cobox_playerposition
            // 
            this.cobox_playerposition.FormattingEnabled = true;
            this.cobox_playerposition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cobox_playerposition.Location = new System.Drawing.Point(885, 161);
            this.cobox_playerposition.Name = "cobox_playerposition";
            this.cobox_playerposition.Size = new System.Drawing.Size(207, 28);
            this.cobox_playerposition.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1104, 444);
            this.Controls.Add(this.cobox_playerposition);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txbx_playernumber);
            this.Controls.Add(this.txbx_playername);
            this.Controls.Add(this.txbx_teamname);
            this.Controls.Add(this.txbx_teamcity);
            this.Controls.Add(this.txbx_teamcountry);
            this.Controls.Add(this.btn_AddPlayer);
            this.Controls.Add(this.lbl_PlayerPosition);
            this.Controls.Add(this.lbl_AddingPlayers);
            this.Controls.Add(this.lbl_PlayerNumber);
            this.Controls.Add(this.lbl_PlayerName);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.lbl_TeamCity);
            this.Controls.Add(this.lbl_AddingTeam);
            this.Controls.Add(this.lbl_TeamCountry);
            this.Controls.Add(this.lbl_TeamName);
            this.Controls.Add(this.cobox_Team);
            this.Controls.Add(this.lbl_ChooseTeam);
            this.Controls.Add(this.lbl_ChooseCountry);
            this.Controls.Add(this.listbox_Player);
            this.Controls.Add(this.cobox_Country);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.lbl_SoccerTL);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Soccer Team";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_SoccerTL;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.ComboBox cobox_Country;
        private System.Windows.Forms.ListBox listbox_Player;
        private System.Windows.Forms.Label lbl_ChooseCountry;
        private System.Windows.Forms.Label lbl_ChooseTeam;
        private System.Windows.Forms.ComboBox cobox_Team;
        private System.Windows.Forms.Label lbl_TeamCountry;
        private System.Windows.Forms.Label lbl_TeamName;
        private System.Windows.Forms.Label lbl_AddingTeam;
        private System.Windows.Forms.Label lbl_TeamCity;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Button btn_AddPlayer;
        private System.Windows.Forms.Label lbl_PlayerPosition;
        private System.Windows.Forms.Label lbl_AddingPlayers;
        private System.Windows.Forms.Label lbl_PlayerNumber;
        private System.Windows.Forms.Label lbl_PlayerName;
        private System.Windows.Forms.TextBox txbx_teamcountry;
        private System.Windows.Forms.TextBox txbx_teamcity;
        private System.Windows.Forms.TextBox txbx_teamname;
        private System.Windows.Forms.TextBox txbx_playername;
        private System.Windows.Forms.TextBox txbx_playernumber;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ComboBox cobox_playerposition;
    }
}

