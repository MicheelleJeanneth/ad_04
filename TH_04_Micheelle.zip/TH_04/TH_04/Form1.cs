﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_04
{
    public partial class Form1 : Form
    {
        Player player = new Player();
        Team team = new Team();
        
        List<string> choosecountry = new List<string>();
        List<string> chooseplayer = new List<string>();

        DataTable dtteam = new DataTable();
        DataTable dtplayer = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[,] ManchesterC = new string[11, 3]
                                    {{"31","Ederson","GK"}, {"02", "Kyle Walker", "DF"}, {"05", "John Stones", "DF"},
                                    {"82", "Rico Lewis", "DF"}, {"24", "Josko Gvardiol", "DF"}, {"10", "Jack Grealish", "MF"},
                                    {"47", "Phil Foden", "MF"}, {"08", "Mateo Kovacic", "MF"}, {"09", "Erling Haaland", "FW"},
                                    {"19", "Julian Alvarez", "FW"}, {"11", "Jeremy Doku", "FW"}};

            string[,] LiverpoolFC = new string[11, 3]
                                    {{"01", "Alisson", "GK"}, {"02", "Joe Gomez", "DF"}, {"26", "Andy Robertson", "DF"},
                                    {"78", "Jarell Quansah", "DF"}, {"32", "Joel Matip", "DF"}, {"17", "Curtis Jones", "MF"},
                                    {"19", "Harvey Elliott", "MF"}, {"53", "James McConnell", "MF"}, {"07", "Luis Diaz", "FW"},
                                    {"20", "Diogo Jota", "FW"}, {"50", "Ben Doak", "FW"}};

            string[,] InterM = new string[11, 3]
                                    {{"77", "Emil Audero", "GK"}, {"06", "Stefan De Vrij", "DF"}, {"15", "Francesco Acerbi", "DF"},
                                    {"28", "Benjamin Pavard", "DF"}, {"31", "Yann Aurel Bisseck", "DF"}, {"02", "Denzel Dumfries", "MF"},
                                    {"05", "Stefano Sensi", "MF"}, {"07", "Juan Cuadrado", "MF"}, {"10", "Lautaro Martinez", "FW"},
                                    {"08", "Marko Arnautovic", "FW"}, {"70", "Alexis Sanchez", "FW"}};

            dataGridView2.DataSource = dtplayer;

            dtteam.Columns.Add("Country");
            dtteam.Columns.Add("Team");
            dtteam.Columns.Add("City");
            dtteam.Rows.Add("England", "Manchester City", "Cambridge");
            dtteam.Rows.Add("England", "Liverpool FC", "Liverpool");
            dtteam.Rows.Add("Italy", "Inter Milan", "Milan");
            dataGridView1.DataSource = dtteam;

            dtplayer.Columns.Add("Team");
            dtplayer.Columns.Add("Player Name");
            dtplayer.Columns.Add("Player Number");
            dtplayer.Columns.Add("Player Position");

            for (int i = 0; i < 11; i++)
            {
                dtplayer.Rows.Add("Manchester City", ManchesterC[i, 1], ManchesterC[i, 0], ManchesterC[i, 2]);
            }

            for (int i = 0; i < 11; i++)
            {
                dtplayer.Rows.Add("Liverpool FC", LiverpoolFC[i, 1], LiverpoolFC[i, 0], LiverpoolFC[i, 2]);
            }
            for (int i = 0; i < 11; i++)
            {
                dtplayer.Rows.Add("Inter Milan", InterM[i, 1], InterM[i, 0], InterM[i, 2]);
            }
            
            dataGridView2.DataSource = dtplayer;
        }

        private void cobox_Country_SelectedIndexChanged(object sender, EventArgs e)
        {
            cobox_Team.Items.Clear();
            for (int i = 0;i < dtteam.Rows.Count;i++) 
            {
                if (cobox_Country.SelectedItem == dtteam.Rows[i][0])
                {
                    cobox_Team.Items.Add(dtteam.Rows[i][1]);
                }
            }
        }

        private void cobox_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            listbox_Player.Items.Clear();
            for (int i = 0; i < dtplayer.Rows.Count; i++)
            {
                if (cobox_Team.SelectedItem == dtplayer.Rows[i][0])
                {
                    listbox_Player.Items.Add("(" + dtplayer.Rows[i][2] + ") " + dtplayer.Rows[i][1] + ", " + dtplayer.Rows[i][3]);
                }
            }
            listbox_Player.Sorted = true;
        }

        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            if (txbx_teamname.Text == "" || txbx_teamcountry.Text == "" || txbx_teamcity.Text == "")
            {
                DialogResult dr = MessageBox.Show("All Fields Need To Be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txbx_teamcountry.Text = "";
                txbx_teamname.Text = "";
                txbx_teamcity.Text = "";
            }
            else
            {
                bool sama = false;
                for (int i = 0; i < dtteam.Rows.Count; i++)
                {
                    if (txbx_teamname.Text == dtteam.Rows[i][1].ToString())
                    {
                        sama = true;
                        break;
                    }
                    else
                    {
                        sama = false;
                    }
                }
                if (sama == false)
                {
                    dtteam.Rows.Add(txbx_teamcountry.Text, txbx_teamname.Text, txbx_teamcity.Text);
                    txbx_teamcountry.Text = "";
                    txbx_teamname.Text = "";
                    txbx_teamcity.Text = "";
                }
                else if (sama == true)
                {
                    DialogResult dr = MessageBox.Show("Team Has Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txbx_teamcountry.Text = "";
                    txbx_teamname.Text = "";
                    txbx_teamcity.Text = "";
                }
            }
        }

        private void cobox_Country_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void cobox_Country_Click(object sender, EventArgs e)
        {
            cobox_Team.Items.Clear();
            cobox_Country.Items.Clear();
            string nama = " ";
            cobox_Country.Items.Add(dtteam.Rows[0][0]);

            for (int i = 0; i < dtteam.Rows.Count; i++)
            {
                nama = (dtteam.Rows[i][0].ToString());
                string nama1 = " ";
                bool ketemu = false;
                for (int j = 0; j < cobox_Country.Items.Count; j++)
                {
                    nama1 = cobox_Country.Items[j].ToString();
                    if (nama == nama1)
                    {
                        ketemu = true;
                        break;
                    }
                    else
                    {
                        ketemu = false;
                    }
                }
                if (ketemu == false)
                {
                    cobox_Country.Items.Add(dtteam.Rows[i][0]);
                }
            }
        }

        private void cobox_Team_Click(object sender, EventArgs e)
        {
            cobox_Team.Items.Clear();
            string country1 = " ";

            for (int i = 0; i < dtteam.Rows.Count; i++)
            {
                country1 = dtteam.Rows[i][0].ToString();
                if (country1 == cobox_Country.SelectedItem.ToString()) 
                {
                    cobox_Team.Items.Add(dtteam.Rows[i][1]);
                }
            }
        }

        private void btn_AddPlayer_Click(object sender, EventArgs e)
        {
            if (txbx_playername.Text == "" || txbx_playernumber.Text == "" || cobox_playerposition.SelectedIndex == -1) 
            {
                DialogResult dr = MessageBox.Show("All Fields Need To Be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txbx_playername.Text = "";
                txbx_playernumber.Text = "";
                cobox_playerposition.SelectedIndex = -1;
            }
            else
            {
                bool ada = false;
                string team1 = " ";
                string num = " ";
                for (int i = 0; i < dtplayer.Rows.Count; i++)
                {
                    team1 = dtplayer.Rows[i][0].ToString();
                    if (team1 == cobox_Team.SelectedItem.ToString())
                    {
                        if (txbx_playernumber.Text.Length == 1)
                        {
                            num = "0" + txbx_playernumber.Text;
                        }
                        else
                        {
                            num = txbx_playernumber.Text;
                        }
                        if (dtplayer.Rows[i][2].ToString() == num)
                        {
                            ada = true;
                            break;
                        }
                        else
                        {
                            ada = false;
                        }
                    }
                }
                if (ada == true)
                {
                    DialogResult dr = MessageBox.Show("Player With The Same Number Is Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txbx_playername.Text = "";
                    txbx_playernumber.Text = "";
                    cobox_playerposition.SelectedIndex = -1;
                }
                else if (ada == false)
                {
                    if (txbx_playernumber.Text.Length == 1)
                    {
                        string a = "0" + txbx_playernumber.Text;
                        dtplayer.Rows.Add(cobox_Team.SelectedItem.ToString(), txbx_playername.Text, a, cobox_playerposition.SelectedItem);
                        listbox_Player.Items.Add("(" + a + ") " + txbx_playername.Text + ", " + cobox_playerposition.SelectedItem);
                        txbx_playername.Text = "";
                        txbx_playernumber.Text = "";
                        cobox_playerposition.SelectedIndex = -1;
                    }
                    else
                    {
                        dtplayer.Rows.Add(cobox_Team.SelectedItem.ToString(), txbx_playername.Text, txbx_playernumber.Text, cobox_playerposition.SelectedItem);
                        listbox_Player.Items.Add("(" + txbx_playernumber.Text + ") " + txbx_playername.Text + ", " + cobox_playerposition.SelectedItem);
                        txbx_playername.Text = "";
                        txbx_playernumber.Text = "";
                        cobox_playerposition.SelectedIndex = -1;
                    }
                }
            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (listbox_Player.Items.Count <= 11)
            {
                DialogResult dr = MessageBox.Show("Unable To Remove Players If Players Less Than Equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool ketemu = false;
                int ke = 0;
                string pilih = listbox_Player.SelectedItem.ToString();
                string angka = "";
                for (int i = 0; i < pilih.Length; i++)
                {
                    if (pilih[i].ToString() == "0" || pilih[i].ToString() == "1" || pilih[i].ToString() == "2" || pilih[i].ToString() == "3" ||
                        pilih[i].ToString() == "4" || pilih[i].ToString() == "5" || pilih[i].ToString() == "6" || pilih[i].ToString() == "7" ||
                        pilih[i].ToString() == "8" || pilih[i].ToString() == "9")
                    {
                        angka = angka + pilih[i].ToString();
                    }
                }

                for (int j = 0; j < dtplayer.Rows.Count; j++)
                {
                    if (angka == dtplayer.Rows[j][2].ToString())
                    {
                        ketemu = true;
                        ke = j;
                        break;
                    }
                    else
                    {
                        ketemu = false;
                    }
                }

                if (ketemu == true)
                {
                    dtplayer.Rows.RemoveAt(ke);
                    listbox_Player.Items.Clear();
                    for (int i = 0; i < dtplayer.Rows.Count; i++)
                    {
                        if (cobox_Team.SelectedItem == dtplayer.Rows[i][0])
                        {
                            listbox_Player.Items.Add("(" + dtplayer.Rows[i][2] + ") " + dtplayer.Rows[i][1] + ", " + dtplayer.Rows[i][3]);
                        }
                    }
                    listbox_Player.Sorted = true;
                }
            }
        }
    }
}